import { Component } from '@angular/core';
import { IonicPage, NavController, AlertController } from 'ionic-angular';
import { Data } from '../../providers/data/data';


@IonicPage()
@Component({
  selector: 'page-task',
  templateUrl: 'task.html',
})
export class TaskPage {

	tasks: any = [];

  constructor(public navCtrl: NavController, public alertCtrl: AlertController, public dataService: Data) {

    this.dataService.getData().then((todos) => {
 
      if(todos){
        this.tasks = todos;
      }
 
    });

  }

  addTask() {

    let prompt = this.alertCtrl.create ({
      title:'New Task',
      inputs: [{
        name: 'title'
      }],
      buttons: [
        {

          text: 'Cancel'

        },
        {

          text: 'Add',
          handler: data => {

            this.tasks.push(data);
            this.dataService.save(this.tasks);

          }

        }
      ]
    });

    prompt.present();

  }

  editTask(task) {

    let prompt = this.alertCtrl.create ({

      title: 'Edit Task',
      inputs: [{
        name: 'title'
      }],
      buttons: [

        {

          text: 'Cancel'

        },
        {

          text: 'Save',
          handler: data => {

            let index = this.tasks.indexOf(task);

            if(index > -1) {
              this.tasks[index] = data;

            }
            this.dataService.save(this.tasks);

          }

        }

      ]

    });

    prompt.present();

   }

   deleteTask(task) {

    let index = this.tasks.indexOf(task);

    if(index > -1) {
      this.tasks.splice(index, 1);
    }
    this.dataService.save(this.tasks);
   }

}
